// Playground - noun: a place where people can play

import UIKit

class Person {
    
    var name:String?
    var address:String?
    
    init(personName:String, personAddress:String) {
        
        self.name = personName
        self.address = personAddress
        
    }
    
    func getName() -> String {
        
        return name!
        
    }
    
    deinit{
        
        var removal = getName()
        println("Removing from memory \(removal)")
    }
    
}



class Employee:Person {
    
    var companyName:String?
    var joinDate:String?
    
    init(personName: String, personAddress: String, personCompanyName:String, personJoinDate:String) {
        
        super.init(personName:personName,personAddress:personAddress)
        
        
        self.companyName = personCompanyName
        self.joinDate = personJoinDate
        
    }
    
}

//Create two Person objects

var nyGuy = Person(personName:"John",personAddress:"Queens, NY")

var caGuy = Person(personName:"Jill",personAddress:"LA, California")


//Create an employee object

var tc = Employee(personName:"TC",personAddress:"LA",personCompanyName:"Apple",personJoinDate:"1998")


var empName = caGuy.getName()

var somebody:AnyObject?

somebody = nyGuy

//Check if someone is an employee or not

if somebody is Employee {
    
    println("an employee")
    
} else {
    
    println("not an employee")
    
}

// 6. ------------- Arrays ------------------

println("\n\n-------------6. Arrays ----------\n\n")

var personArray = [nyGuy, caGuy, tc]

println("Printing names ...")

for person in personArray {
    
    var p:Person
    p = person
    
    println(p.getName())
    
    
    if p is Employee {
        
        println("an employee")
        
    } else {
        
        println("not an employee")
        
    }
    
}



//7. ---------- Dictionaries -----------------


println("\n\n ---------- 7. Dictionaries ----------\n\n")

var peopleDirectory = Dictionary<String, Person>()

peopleDirectory.updateValue(tc, forKey:"Tim")
peopleDirectory.updateValue(nyGuy, forKey:"John")
peopleDirectory.updateValue(caGuy, forKey:"Jill")


//Look for someone
var someone:Person? = peopleDirectory["Jill"]


var name = someone!.getName()


//remove Tim from the dictionary

peopleDirectory.removeValueForKey("Tim")

someone = peopleDirectory["Fred"]


for people in peopleDirectory.values {
    
    println(people.getName())
    
}



