//
//  ViewController.swift
//  Class5_MemoryManagement
//
//  Created by Aditya Narayan on 7/28/14.
//  Copyright (c) 2014 Aditya Narayan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
                            
    //------- Declare instance vars -----
    
    //-----------------------------------
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //----- Declare all references to UI elements -----------
    
    
    @IBOutlet var numSimpleObjectsToCreateTF : UITextField!
    
    
    @IBOutlet var numSimpleObjsLabel : UILabel!
    
    //----- END: Declare all references to UI elements ------

    
    //---- START: Stage 1 - Simple object demo ------------------------
    
    
    //Instance var
    var singleObj:SimpleClass?
    
    @IBOutlet var objCount : UILabel!
    
    @IBAction func createSimpleObject() {
        
        //Local variable
        
        //var singleObj:SimpleClass?
        
        
        println("\n\n------------------------Stage 1 - Simple object demo------------------------")
        
        singleObj = SimpleClass(id:10000)
        
        //singleObj = nil
        
        //singleObj = SimpleClass(id:10001)
        
        
        println("\nLast Line in function \n\n")
        
    }
    
    
    @IBAction func releaseSimpleObject() {
        
        self.singleObj = nil
        
        println("\n\nTried to release simple object. deinit must be called\n\n")
        
    }
    
    //---- END: Stage 1 - Simple object demo ------------------------
    
    
    
    //---- START: Stage 2 - Simple object demo ------------------------
    
    
    var simpleObjArray = [SimpleClass]()
    
    //var simpleObjArray:[SimpleClass]?

    
    @IBAction func createSimpleObjects() {
        
        println("\n\n------------------------Stage 2 - Simple object demo------------------------")
        
        var numObjects:Int?
       
        
        numObjects = self.numSimpleObjectsToCreateTF.text.toInt()
        
        for var i = 0; i < numObjects; i++ {
            
            
            var myObj:SimpleClass =  SimpleClass(id:i)
            
            simpleObjArray.append(myObj)
            
        }
        
        self.numSimpleObjsLabel.text = "\(simpleObjArray.count)"
        
        println("\n\n Created \(simpleObjArray.count) simple objects\n\n")
        
    }
    
    
    @IBAction func releaseSimpleObjRefs() {
        
        
//        for var i = 0; i < simpleObjArray.count; i++ {
//            
//            var myObj:SimpleClass? = simpleObjArray[i]
//            
//            var id = myObj!.simpleClassId
//            
//            myObj = nil
//            
//        }

        println("\n\nCalling removeAll on array with \(simpleObjArray.count) elements, individual elements will get deallocated now ...\n\n")

        
       self.simpleObjArray.removeAll(keepCapacity: false)
        
        //self.simpleObjArray = nil
        
 //       self.numSimpleObjsLabel.text = "\(simpleObjArray.count)"
        
        
    }
    
    @IBAction func getNumSimpleObjects() {
        
        self.numSimpleObjsLabel.text = "\(simpleObjArray.count)"
        
    }
    
    
    //---- END: Stage 2 - Simple object demo ------------------------
    
    
    
    //---- START: Stage 3 - Strong retain cycle demo ------------------------
    
    
    var strongRetainDemoObjArrayOfAppPlatforms = [AppPlatform]()
    
    var myLang:AppProgrammingLanguage?
    var myPf:AppPlatform?

    
    @IBAction func createObjectsForStrongRetainCycleDemo() {
        
            println("\n\n------------------------Stage 3 - Strong retain cycle demo------------------------")
        
//            var myLang:AppProgrammingLanguage?
//            var myPf:AppPlatform?
        
            //Create objects with a strong retain cycle
        
            myLang = AppProgrammingLanguage(progLangName: "C#", platform: nil)
            myPf =  AppPlatform(platformName: "Windows Phone", language: myLang!)
        
            myLang!.applicableToPlatform = myPf
        
            println("\n\nInstance variables for Windows and C# created ...\n\n")
        
        
    }
    
    
    @IBAction func releaseObjectsForStrongRetainDemo() {
        
        
        //Note: Once this method exits, the two object references are no longer needed. Do the objects get deinitialized?
        
        //Task 1: Uncomment the following to explicitly set them to nil. What happens?
        myPf = nil
        
        myLang = nil
       

        println("\n\nTried to release cross-referenced objects. deinit must be called\n\n")
        
    }
    
    //---- END: Stage 3 - Strong retain cycle demo ------------------------
    
    
    //---- START: Stage 4 - Strong retain cycle demo ----------------------
    
    
    @IBAction func createObjectsThatGoOutOfScope() {
        
        //Create objects with a strong retain cycle
        
        println("\n\n------------------------Stage 4 - Strong retain cycle demo------------------------")
        
        var myLang:AppProgrammingLanguage = AppProgrammingLanguage(progLangName: "Java", platform: nil)
        var myPf:AppPlatform =  AppPlatform(platformName: "Android", language: myLang)
        
        myLang.applicableToPlatform = myPf
        
        println("\n\nLocal variables for Android and Java created ...\n\n")
        
        println("\n\nLocal variables going out of scope now ...\n\n")
        
    }
    
    //---- END: Stage 4 - Strong retain cycle demo ------------------------
    
    
}

