//
//  Login.swift
//  FirstApp
//
//  Created by Aditya Narayan on 8/4/14.
//  Copyright (c) 2014 QCD Systems. All rights reserved.
//

import Foundation

class Login {
    
    func performAction() {
        
        
        println("checking login ...")
        
        //--- go to a custom database
        
        //---- OAuth ---
        
    }
    
    
}